<div id="main-content-wp" class="thank-page">
    <div class="wp-inner clearfix">
        <div id="sidebar" class="fl-left">
            <div id="main-menu-wp">
                <ul class="list-item">
                    <li class="active">
                        <a href="?page=home" title="Trang chủ">Trang chủ</a>
                    </li>
                    <li>
                        <a href="?page=detail_news" title="Giới thiệu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="?page=category_product" title="">Laptop</a>
                    </li>
                    <li>
                        <a href="?page=category_product" title="">Điện thoại</a>
                    </li>
                    <li>
                        <a href="?page=category_product" title="">Máy tính bảng</a>
                    </li>
                    <li>
                        <a href="?page=detail_news" title="Liên hệ">Liên hệ</a>
                    </li>
                </ul>
            </div>
        </div>
        <div id="content" class="fl-right">
            <div class="section" id="thank-wp">
                <div class="section-head">
                    <h3 class="section-title">Đặt hàng thành công</h3>
                </div>
                <div class="section-detail">
                    <p>Chúc mừng bạn đã đặt hàng thành công. Vui lòng kiểm tra địa chỉ <a href="https://mail.google.com/" title="Email">Email</a> để kiểm tra đơn hàng!</p>
                </div>
            </div>
        </div>
    </div>
</div>