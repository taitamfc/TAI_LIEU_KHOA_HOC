<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">© 2018 Copyright unitop.vn</p>
    </div>
</div>
</div>
<div id="menu-respon">
    <a href="?page=home" title="" class="logo">Vietsoz Shop</a>
    <div id="menu-respon-wp">
        <ul class="" id="main-menu-respon">
            <li>
                <a href="?page=home" title="Trang chủ">Trang chủ</a>
            </li>
            <li>
                <a href="?page=detail_news" title="Giới thiệu">Giới thiệu</a>
            </li>
            <li>
                <a href="?page=category_product" title="">Laptop</a>
            </li>
            <li>
                <a href="?page=category_product" title="">Điện thoại</a>
            </li>
            <li>
                <a href="?page=category_product" title="">Máy tính bảng</a>
            </li>
            <li>
                <a href="?page=detail_news" title="Liên hệ">Liên hệ</a>
            </li>
        </ul>
    </div>
</div>
</div>
</body>
</html>